class Foo {
    public:
    	void bar();
};
